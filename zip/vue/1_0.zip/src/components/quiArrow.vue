<template>
  <a class="qui-arrow">❯</a>
</template>

<script>
  export default {

  }
</script>
<style scoped>
  .qui-arrow{
    font-size: 18px;
    color: #aaa;
    margin-right: 10px;
  }
</style>

