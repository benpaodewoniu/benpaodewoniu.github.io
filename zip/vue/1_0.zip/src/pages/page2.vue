//page-2.vue
<template>
  <div>子页面</div>
</template>
