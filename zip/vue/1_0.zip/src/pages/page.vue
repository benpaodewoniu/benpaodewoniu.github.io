//page.vue
<template>
    <router-view></router-view>
</template>
