//page-1.vue
<template>
  <div>默认页面</div>
</template>
