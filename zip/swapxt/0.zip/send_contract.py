import json
import os
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import threading

import xlrd
from web3 import Web3

w3 = Web3(Web3.HTTPProvider('https://http-mainnet.hoosmartchain.com'))

file_name = "3000_1.xlsx"


"""
3000_1
6.11

3000_2
"""

ixt_contract = "0x80c6A3A493aFd7C52f89E6504C90cE6A639783FC"
iusdt_contract = "0x09e6030537f0582d51C00bdC2d590031d9b1c86c"

abi = json.loads(
    '[{"constant": true,"inputs": [{"name": "who", "type": "address"}],"name": "balanceOf","outputs": [{"name": "", "type": "uint256"}],"payable": false,"stateMutability": "view","type": "function"}]')

iXT_ADDRESS = w3.toChecksumAddress('0x80c6A3A493aFd7C52f89E6504C90cE6A639783FC')
iUSDT_ADDRESS = w3.toChecksumAddress('0x09e6030537f0582d51C00bdC2d590031d9b1c86c')
iXT_CONTRACT = w3.eth.contract(address=iXT_ADDRESS, abi=abi)
iUSDT_CONTRACT = w3.eth.contract(address=iUSDT_ADDRESS, abi=abi)


def init_address():
    data = defaultdict(list)
    xls = xlrd.open_workbook(file_name)
    for i in range(len(xls.sheets()[0].col_values(0))):
        data[xls.sheets()[0].col_values(0)[i]] = xls.sheets()[0].col_values(1)[i]
    return data


def get_ixt(address):
    address = Web3.toChecksumAddress(address)
    print(address + " " + str(threading.current_thread().name) + " " + str(
        w3.fromWei(iXT_CONTRACT.functions.balanceOf(address).call(), 'ether')))


def get_erc20(address, private):
    toAddress = Web3.toChecksumAddress('0x126c2C418aE620da41D14bD96c5af49164794C88')
    fromAddress = Web3.toChecksumAddress(address)
    nonce = w3.eth.getTransactionCount(fromAddress)
    transaction = {
        'from': fromAddress,
        'to': toAddress,
        'gas': 241838,
        'gasPrice': w3.toWei('1', 'gwei'),
        'nonce': nonce,
        'data': "c9972e44",
        # 'chainId': 70
    }
    signed_tx = w3.eth.account.signTransaction(transaction, private)
    txn_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
    print(address + " " + str(threading.current_thread().name) + " " + Web3.toHex(txn_hash))


if __name__ == '__main__':
    data = init_address()
    pool = ThreadPoolExecutor(max_workers=20)
    index = 1
    for address, private in data.items():
        # pool.submit(get_erc20, address, private)
        # 运行完上面运行下面，不要同时运行，太快了，浏览器没那么快更新
        pool.submit(get_ixt, address)
