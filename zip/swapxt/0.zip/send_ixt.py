import json
import threading
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor

import xlrd
from web3 import Web3

w3 = Web3(Web3.HTTPProvider('https://http-mainnet.hoosmartchain.com'))

file_name = "3000_2.xlsx"

ixt_contract = "0x80c6A3A493aFd7C52f89E6504C90cE6A639783FC"
iusdt_contract = "0x09e6030537f0582d51C00bdC2d590031d9b1c86c"

abi = json.loads(
    '[{"constant": true,"inputs": [{"name": "who", "type": "address"}],"name": "balanceOf","outputs": [{"name": "", "type": "uint256"}],"payable": false,"stateMutability": "view","type": "function"},'
    '{"constant":false,"inputs":[{"name":"_to","type":"address"},{"name":"_value","type":"uint256"}],"name":"transfer","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"}]')

iXT_ADDRESS = w3.toChecksumAddress('0x80c6A3A493aFd7C52f89E6504C90cE6A639783FC')
iXT_CONTRACT = w3.eth.contract(address=iXT_ADDRESS, abi=abi)


def init_address():
    data = defaultdict(list)
    xls = xlrd.open_workbook(file_name)
    for i in range(len(xls.sheets()[0].col_values(0))):
        data[xls.sheets()[0].col_values(0)[i]] = xls.sheets()[0].col_values(1)[i]
    return data


def get_ixt(address):
    address = Web3.toChecksumAddress(address)
    return w3.fromWei(iXT_CONTRACT.functions.balanceOf(address).call(), 'ether')


def send_ixt(address, private):
    toAddress = Web3.toChecksumAddress('地址')
    fromAddress = Web3.toChecksumAddress(address)
    ixt = get_ixt(fromAddress)
    if ixt > 0:
        nonce = w3.eth.getTransactionCount(fromAddress)
        transaction = iXT_CONTRACT.functions.transfer(toAddress, w3.toWei(ixt, "ether")).buildTransaction({
            'gas': 241838,
            'gasPrice': w3.toWei('1', 'gwei'),
            'nonce': nonce,
        })
        signed_tx = w3.eth.account.signTransaction(transaction, private)
        txn_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
        print(address + " " + str(threading.current_thread().name) + " " + Web3.toHex(txn_hash))


if __name__ == '__main__':
    data = init_address()
    pool = ThreadPoolExecutor(max_workers=20)
    for address, private in data.items():
        pool.submit(send_ixt, address, private)
