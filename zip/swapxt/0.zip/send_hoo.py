from web3 import Web3
import time
import xlrd
from concurrent.futures import ThreadPoolExecutor

w3 = Web3(Web3.HTTPProvider('https://http-mainnet.hoosmartchain.com'))

user_hoo = 0.005

private_key = "地址私钥"
address = "地址公钥"

sleep_time = 5
# file_name = "3000_1.xlsx"
file_name = "3000_1.xlsx"



def init_address():
    xls = xlrd.open_workbook(file_name)
    addresses = xls.sheets()[0].col_values(0)
    print("一共有 " + str(len(addresses)) + " 地址")
    return addresses


def send_hoo():
    fromAddress = Web3.toChecksumAddress(address)
    addresseres = init_address()
    for _add in addresseres:
        toAddress = Web3.toChecksumAddress(_add)
        nonce = w3.eth.getTransactionCount(fromAddress)
        balance = w3.eth.get_balance(toAddress)
        if w3.fromWei(balance, "ether") >= user_hoo:
            continue
        gasPrice = w3.eth.gasPrice
        value = Web3.toWei(user_hoo, 'ether')
        gas = w3.eth.estimateGas({'from': fromAddress, 'to': toAddress, 'value': value})
        transaction = {'from': fromAddress,
                       'to': toAddress,
                       'nonce': nonce,
                       'gasPrice': gasPrice,
                       'gas': gas,
                       'value': value,
                       'data': ''}

        signed_tx = w3.eth.account.signTransaction(transaction, private_key)
        txn_hash = w3.eth.sendRawTransaction(signed_tx.rawTransaction)
        print(Web3.toHex(txn_hash))
        print(toAddress)
        time.sleep(5)
        while w3.eth.getTransactionCount(fromAddress) == nonce:
            time.sleep(1)


def check_hoo(address):
    # 检查每个地址的 hoo 数量
    checkAddress = Web3.toChecksumAddress(address)
    balance = w3.eth.get_balance(checkAddress, 'latest')
    print('地址{0} => {1}'.format(address, w3.fromWei(balance, 'ether')))
    time.sleep(0.1)


if __name__ == '__main__':
    # 分发 hoo 只能顺序分发
    # send_hoo()
    # 查看地址上 hoo 的量
    addresses = init_address()
    pool = ThreadPoolExecutor(max_workers=20)
    for address in addresses:
        pool.submit(check_hoo, address)
