from web3 import Web3

from huoshan.thlmairdrop.Config.config import rpc

w3 = Web3(Web3.HTTPProvider(rpc))


def balance(address):
    return w3.eth.get_balance(address)


if __name__ == '__main__':
    address = w3.toChecksumAddress("0x5122cf747906A22842d25dfcd10DAF6A166160de")
    print(balance(address))
