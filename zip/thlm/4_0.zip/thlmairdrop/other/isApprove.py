from web3 import Web3

from huoshan.thlmairdrop.Config.config import BASE_ABI, rpc, CONTRACT, THLM

w3 = Web3(Web3.HTTPProvider(rpc))


def get_balance(contract, address, spend):
    contract_ = w3.eth.contract(
        address=Web3.toChecksumAddress(contract), abi=BASE_ABI)

    is_approve = contract_.functions.allowance(Web3.toChecksumAddress(address), Web3.toChecksumAddress(spend)).call()
    return is_approve


if __name__ == '__main__':
    token_contract = THLM

    address = "0x71Dc836550c22e4db0002d3DE077A503f2f36f0A"
    spend = CONTRACT  # 授权合约

    print(get_balance(token_contract, address, spend))
