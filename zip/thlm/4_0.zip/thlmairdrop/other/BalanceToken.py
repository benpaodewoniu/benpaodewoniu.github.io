from web3 import Web3

from huoshan.thlmairdrop.Config.config import BASE_ABI, rpc,THLM

w3 = Web3(Web3.HTTPProvider(rpc))


def get_balance(contract, address):
    contract_ = w3.eth.contract(
        address=Web3.toChecksumAddress(contract), abi=BASE_ABI)

    balance = contract_.functions.balanceOf(Web3.toChecksumAddress(address)).call()
    return balance


if __name__ == '__main__':
    address = "0x5122cf747906A22842d25dfcd10DAF6A166160de"
    print(get_balance(THLM, address))
