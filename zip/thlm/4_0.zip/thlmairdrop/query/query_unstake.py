from web3 import Web3

from huoshan.thlmairdrop.Config.config import ABI, rpc, CONTRACT, owner_address

w3 = Web3(Web3.HTTPProvider(rpc))

contract_ = w3.eth.contract(
    address=Web3.toChecksumAddress(CONTRACT), abi=ABI)

address = Web3.toChecksumAddress(owner_address)
info = contract_.functions.queryUnstake(address).call()
print(info)

# 1784442798
# 1784442822