import random
import sys
import time

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains

botid = sys.argv[1]


def log(msg):
    print("[{}] {}".format(botid, msg))


def click_canvas(driver, x_percent, y_percent, memo=""):
    canvas = driver.find_element_by_id('unityContainer').find_element_by_tag_name("canvas")
    size = canvas.size
    width = size['width'] * x_percent
    height = size['height'] * y_percent
    log("canvas:{} {}".format(size, memo))
    action = ActionChains(driver)
    action.move_to_element_with_offset(canvas, width, height).click().perform()
    time.sleep(0.5)


def click_window(driver, x_percent, y_percent, memo=""):
    root = driver.find_element_by_id('root')
    size = root.size
    width = size['width'] * x_percent
    height = size['height'] * y_percent
    log("window:{} {}".format(size, memo))
    action = ActionChains(driver)
    action.move_to_element_with_offset(root, width, height).click().perform()
    time.sleep(1)


def newWindowListen(driver, current_handle):
    log(current_handle)
    for i in driver.window_handles:
        if not i == current_handle:
            check = 0
            while True:
                log('check error')
                time.sleep(0.1)
                click_canvas(driver, 0.76, 0.25, "error check")
                time.sleep(0.1)
                click_canvas(driver, 0.5, 0.6, "claim")

                check += 1
                if (check == 3):
                    break

            driver.switch_to.window(i)
            count = 0
            while True:
                if len(driver.window_handles) == 1:
                    driver.switch_to.window(current_handle)
                    driver.minimize_window()
                    break
                else:
                    if count < 15:
                        try:
                            click_window(driver, 0.9, 0.9, str(count))
                        except Exception as e:
                            log('popup click:')
                            log(e)
                        time.sleep(5)
                        try:
                            button = driver.find_element_by_class_name("button-text")
                            if button.is_enabled():
                                button.click()
                            time.sleep(5)
                        except Exception as e:
                            log('popup button:')
                            log(e)
                        count += 1
                    else:
                        log('refresh')
                        driver.refresh()
                        driver.switch_to.window(current_handle)
                        driver.minimize_window()
                        break


def mine():
    chrome_options = Options()
    chrome_options.add_argument('--user-data-dir=C:\\chrome\\' + botid)
    chrome_options.add_argument(
        'user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36')
    # chrome_options.add_argument('--incognito')
    chrome_options.add_experimental_option('useAutomationExtension', True)
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    # chrome_options.add_argument('blink-settings=imagesEnabled=false')
    dr = webdriver.Chrome(executable_path='./chromedriver', options=chrome_options)
    dr.set_window_size(800, 540)

    with open('./stealth.min.js') as f:
        js = f.read()

    dr.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": js
    })

    dr.get('https://play.alienworlds.io/')
    current_handle = dr.current_window_handle

    while (1):
        log("待页面加载出来后，输入'start'开始运行:")
        i = input()
        if i == 'start':
            dr.minimize_window()
            break
        else:
            log("输入错误，请重新输入")
    while (1):
        try:
            localtime = time.localtime(time.time())
            if localtime.tm_hour < 4 or localtime.tm_hour >= 21:
                pass
                # rand_time = random.randint(60,10*60)
                # print("sleep: {}".format(rand_time))
                # time.sleep(rand_time)
                # continue
            elif localtime.tm_hour >= 12 and localtime.tm_hour < 13:
                rand_time = random.randint(60, 10 * 60)
                print("sleep: {}".format(rand_time))
                time.sleep(rand_time)
                continue
            elif localtime.tm_hour >= 18 and localtime.tm_hour < 19:
                rand_time = random.randint(60, 10 * 60)
                print("sleep: {}".format(rand_time))
                time.sleep(rand_time)
                continue
            click_canvas(dr, 0.76, 0.25, "error check")  # 698  784  # 131 469
            click_canvas(dr, 0.8, 0.28, "home mine")
            click_canvas(dr, 0.493, 0.6, "claim")
            click_canvas(dr, 0.5, 0.9, "mine")
            newWindowListen(dr, current_handle)
            click_canvas(dr, 0.28, 0.82, "return hub")

        except Exception as e:
            log('main loop:')
            log(e)
            continue


if __name__ == '__main__':
    mine()
