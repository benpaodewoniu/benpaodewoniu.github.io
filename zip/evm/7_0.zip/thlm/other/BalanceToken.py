from web3 import Web3

from huoshan.thlm.Config.config import BASE_ABI, rpc

w3 = Web3(Web3.HTTPProvider(rpc))


def get_balance(contract, address):
    contract_ = w3.eth.contract(
        address=Web3.toChecksumAddress(contract), abi=BASE_ABI)

    balance = contract_.functions.balanceOf(Web3.toChecksumAddress(address)).call()
    return balance


if __name__ == '__main__':
    contract = "0x803d58Ff1E4A07C9eEfcf9aa5E4a7Fd49e1EbdaE"
    address = "0x48700BC32F022C71361631c3033C3E459A6F53B1"
    print(get_balance(contract, address))
