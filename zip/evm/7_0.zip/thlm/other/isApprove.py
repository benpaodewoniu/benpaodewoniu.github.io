from web3 import Web3

from huoshan.thlm.Config.config import BASE_ABI, rpc

w3 = Web3(Web3.HTTPProvider(rpc))


def get_balance(contract, address, spend):
    contract_ = w3.eth.contract(
        address=Web3.toChecksumAddress(contract), abi=BASE_ABI)

    is_approve = contract_.functions.allowance(Web3.toChecksumAddress(address), Web3.toChecksumAddress(spend)).call()
    return is_approve


if __name__ == '__main__':
    token_contract = "0x803d58Ff1E4A07C9eEfcf9aa5E4a7Fd49e1EbdaE"

    address = "0x71Dc836550c22e4db0002d3DE077A503f2f36f0A"
    spend = "0xE16C42767F330049AfFCDB03FFe3f9a1045322Aa"  # 授权合约

    print(get_balance(token_contract, address, spend))
