from web3 import Web3
import time
from huoshan.thlm.Config.config import ABI, rpc, CONTRACT

w3 = Web3(Web3.HTTPProvider(rpc))

contract_ = w3.eth.contract(
    address=Web3.toChecksumAddress(CONTRACT), abi=ABI)

address = Web3.toChecksumAddress("0x71Dc836550c22e4db0002d3DE077A503f2f36f0A")
info = contract_.functions.queryUnstake(address).call()
print(info)
print(info[0] + info[1])
