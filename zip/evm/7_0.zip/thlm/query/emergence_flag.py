from web3 import Web3

from huoshan.thlm.Config.config import ABI, rpc, CONTRACT

w3 = Web3(Web3.HTTPProvider(rpc))

contract_ = w3.eth.contract(
    address=Web3.toChecksumAddress(CONTRACT), abi=ABI)

state = contract_.functions.emergencyUnstakFlag().call()

print(state)
