from web3 import Web3

from huoshan.thlm.Config.config import ABI, CONTRACT, rpc

w3 = Web3(Web3.HTTPProvider(rpc))

contract_ = w3.eth.contract(
    address=Web3.toChecksumAddress(CONTRACT), abi=ABI)


def encode_stake(level, amount):
    tx_dic = contract_.functions.stake(level, amount). \
        buildTransaction(
        {
            'gas': 500000,
        }
    )
    return tx_dic


def send_transaction(tx_dic, address, private):
    nonce = w3.eth.getTransactionCount(Web3.toChecksumAddress((address)))
    tx_dic["nonce"] = nonce
    tx_dic['gasPrice'] = w3.eth.gasPrice
    sign_tx = w3.eth.account.signTransaction(tx_dic, private_key=private)
    txn_hash = w3.eth.sendRawTransaction(sign_tx.rawTransaction)
    return Web3.toHex(txn_hash)


def get_wait_receipt(tx):
    print(tx)
    data = w3.eth.waitForTransactionReceipt(tx)
    return data


def stake(level, amount, address, private):
    tx_dic = encode_stake(level, amount)
    tx = send_transaction(tx_dic, address, private)
    get_wait_receipt(tx)


if __name__ == '__main__':
    level = 2
    amount = 100 * (10 ** 18)
    address = "0x71Dc836550c22e4db0002d3DE077A503f2f36f0A"
    private = "616c6db2b4b8b2f16e3486af61e2b6947acaebec61f2ae0e04d72e563834870d"
    stake(level, amount, address, private)
