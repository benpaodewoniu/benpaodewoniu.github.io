from web3 import Web3

from huoshan.thlm.Config.config import ABI, CONTRACT, owner_address, owner_private, rpc

w3 = Web3(Web3.HTTPProvider(rpc))

contract_ = w3.eth.contract(
    address=Web3.toChecksumAddress(CONTRACT), abi=ABI)


def encode_pause():
    tx_dic = contract_.functions.pause(). \
        buildTransaction(
        {
            'gas': 500000,
        }
    )
    return tx_dic


def send_transaction(tx_dic, address, private):
    nonce = w3.eth.getTransactionCount(Web3.toChecksumAddress(address))
    tx_dic["nonce"] = nonce
    tx_dic['gasPrice'] = w3.eth.gasPrice
    sign_tx = w3.eth.account.signTransaction(tx_dic, private_key=private)
    txn_hash = w3.eth.sendRawTransaction(sign_tx.rawTransaction)
    return Web3.toHex(txn_hash)


def get_wait_receipt(tx):
    print(tx)
    data = w3.eth.waitForTransactionReceipt(tx)
    return data


def pause():
    tx_dict = encode_pause()
    tx = send_transaction(tx_dict, owner_address, owner_private)
    get_wait_receipt(tx)


if __name__ == '__main__':
    pause()
