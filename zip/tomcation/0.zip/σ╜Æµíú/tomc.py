import time

import requests
import xlrd
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

file_name = "ethprominer.xlsx"
proxyusernm = ""  # 代理帐号
proxypasswd = ""  # 代理密码


def create_proxyauth_extension(proxy_host, proxy_port,
                               proxy_username, proxy_password,
                               scheme='http', plugin_path=None):
    """Proxy Auth Extension

    args:
        proxy_host (str): domain or ip address, ie proxy.domain.com
        proxy_port (int): port
        proxy_username (str): auth username
        proxy_password (str): auth password
    kwargs:
        scheme (str): proxy scheme, default http
        plugin_path (str): absolute path of the extension

    return str -> plugin_path
    """
    import string
    import zipfile

    if plugin_path is None:
        plugin_path = './vimm_chrome_proxyauth_plugin.zip'

    manifest_json = """
    {
        "version": "1.0.0",
        "manifest_version": 2,
        "name": "Chrome Proxy",
        "permissions": [
            "proxy",
            "tabs",
            "unlimitedStorage",
            "storage",
            "<all_urls>",
            "webRequest",
            "webRequestBlocking"
        ],
        "background": {
            "scripts": ["background.js"]
        },
        "minimum_chrome_version":"22.0.0"
    }
    """

    background_js = string.Template(
        """
        var config = {
                mode: "fixed_servers",
                rules: {
                  singleProxy: {
                    scheme: "${scheme}",
                    host: "${host}",
                    port: parseInt(${port})
                  },
                  bypassList: ["foobar.com"]
                }
              };

        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "${username}",
                    password: "${password}"
                }
            };
        }

        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
        """
    ).substitute(
        host=proxy_host,
        port=proxy_port,
        username=proxy_username,
        password=proxy_password,
        scheme=scheme,
    )
    with zipfile.ZipFile(plugin_path, 'w') as zp:
        zp.writestr("manifest.json", manifest_json)
        zp.writestr("background.js", background_js)

    return plugin_path


def init_address():
    with open("./ip.txt", "r") as f:
        data = f.read().split('\n')
        return data


def get_addresses():
    xls = xlrd.open_workbook(file_name)
    addresses = xls.sheets()[0].col_values(0)
    print("一共有 " + str(len(addresses)) + " 地址")
    return addresses


def set_windows(address, proxy, proxyauth_plugin_path):
    chrome_options = Options()
    chrome_options.add_argument(
        'user-agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36')
    chrome_options.add_argument(f"--proxy-server={proxy}")
    chrome_options.add_experimental_option('useAutomationExtension', True)
    chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_extension(proxyauth_plugin_path)
    dr = webdriver.Chrome(options=chrome_options)
    with open('./stealth.min.js') as f:
        js = f.read()

    dr.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": js
    })

    # dr.get("http://httpbin.org/ip")
    # print(dr.page_source)

    dr.set_page_load_timeout(40)
    dr.set_script_timeout(40)

    try:
        dr.get("http://www.tomcatcoin.com")
        dr.find_element_by_id('radd').click()
        dr.find_element_by_id('radd').send_keys(address)
        time.sleep(0.5)
        dr.find_element_by_class_name("big-button").click()
        time.sleep(2)
    except Exception as e:
        raise e
    finally:
        dr.quit()


def get_ip():
    ip = requests.get(
        "代理云地址")
    # return "http://" + proxyusernm + ":" + proxypasswd + "@" + ip.text.strip()
    return ip.text.strip().split(":")[0], ip.text.strip().split(":")[1]


if __name__ == '__main__':
    data = init_address()
    addresses = get_addresses()
    for address in addresses:
        if address in data:
            continue
        try:
            ip, port = get_ip()
            proxyauth_plugin_path = create_proxyauth_extension(
                proxy_host=ip,
                proxy_port=port,
                proxy_username="",
                proxy_password=""
            )
            iii = "http://" + ip + ":" + str(port)
            set_windows(address, iii, proxyauth_plugin_path)
            print(f"{address} is success ip is {ip}")
            with open("./ip.txt", 'a+') as f:
                f.write(address + '\n')
        except Exception as e:
            print(e)
